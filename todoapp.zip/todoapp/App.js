import React from 'react';

import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import TodoDetails from './TodoDetails';

import { SafeAreaView, StyleSheet, View, Text, TextInput, TouchableOpacity, FlatList, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; 
import { AntDesign } from '@expo/vector-icons';
import { Feather } from '@expo/vector-icons'; 
import AsyncStorage from '@react-native-async-storage/async-storage';  
const COLORS = {text: '#f8f7ff', textbg: "#003566", bg: "#FFC300", inputbox: '#e2eafc'};


function HomeScreen({navigation}) { 
  const [textInput, setTextInput] = React.useState('');
  const [summaryInput, setSummaryInput] = React.useState('');

  const [todos, setTodos] = React.useState([]);

  React.useEffect(() => {
    getTodosFromUserDevice();
  }, []);

  React.useEffect(() => {
    saveTodoToUserDevice(todos);
  }, [todos]);

  const ListItem = ({ todo }) => {
    return (
      <TouchableOpacity
        onPress={() => navigation.navigate('Details', { todo })}
      >
        <View style={styles.listItem}>
          <View style={{ flex: 1 }}>
            <Text
              style={{
                fontWeight: 'bold',
                fontSize: 15,
                color: COLORS.text,
                textDecorationLine: todo?.completed ? 'line-through' : 'none',
              }}
            >
              {todo?.task}
            </Text>
          </View>

          {!todo?.completed && (
            <TouchableOpacity
              style={[styles.actionIcon]}
              onPress={() => markTodoComplete(todo?.id)}
            >
              <Feather name="check-square" size={20} color="white" />
            </TouchableOpacity>
          )}

          <TouchableOpacity
            style={[styles.actionIcon, { backgroundColor: 'red' }]}
            onPress={() => deleteTodo(todo?.id)}
          >
            <Feather name="x-square" size={25} color="white" />
          </TouchableOpacity>
        </View>
      </TouchableOpacity>
    );
  };

  const saveTodoToUserDevice = async (todos) => {
    try {
      const stringifyTodos = JSON.stringify(todos);
      await AsyncStorage.setItem('todos', stringifyTodos);
    } catch (e) {
      console.log(e);
    }
  };


  const getTodosFromUserDevice = async (todos) => {
    try {
      const todos = await AsyncStorage.getItem('todos');
      if (todos != null) {
        setTodos(JSON.parse(todos));
      }
    } catch (e) {
      console.log(e);
    }
  };


  const addTodo = () => {
    if(textInput == "") {
      Alert.alert("Error", "Please input todo");
    } else{
      const newTodo = {
        id:Math.random(),
        task: textInput,
        summary: summaryInput,
        completed: false,
      };
      setTodos([...todos, newTodo]);
      setTextInput('');
      setSummaryInput('');
    }
  };


  const markTodoComplete = (todoId) => {
    const newTodos = todos.map((item) => {
        if(item.id == todoId) {
          return {...item, completed:true};
        }
        return item;
      }
    );
    setTodos(newTodos);
  };


  const deleteTodo = (todoId) => {
    const newTodos = todos.filter(item => item.id != todoId);
    Alert.alert("Confirm", "Clear todos?", [{
      text: 'Yes',
      onPress: () => setTodos(newTodos),
    },
    {
      text: "No"
    },
    ]);
  };


  const clearTodos = () => {
    Alert.alert("Confirm", "Clear todos?", [{
      text: 'Yes',
      onPress: () => setTodos([]),
    },
    {
      text: "No"
    },
    ]);
  };

  return <SafeAreaView style={{flex: 1, backgroundColor: COLORS.bg}}>
    <View style={styles.header}>
      <Text style={{fontWeight: 'bold', fontSize: 20, color: COLORS.textbg}}>Your Todos</Text>
      <AntDesign name="delete" size={22} color="red" onPress={clearTodos}/>
    </View>

    <FlatList
      showsVerticalScrollIndicator = {false}
      contentContainerStyle = {{padding: 20, paddingBottom: 100}}
      data={todos}
      renderItem={({item}) => <ListItem todo={item} />}
    />

    <View style={styles.footer}>
      <View style={styles.inputContainer}>
        <TextInput
        style = {{paddingBottom: 10}} 
        placeholder='Add a todo'
        value={textInput}
        maxLength={35}
        onChangeText={(text)=>setTextInput(text)}/>
        <TextInput 
        placeholder='Add details'
        value={summaryInput}
        maxLength={100}
        multiline={true}
        textAlignVertical='left'
        onChangeText={(details)=>setSummaryInput(details)}/>
      </View>
      <TouchableOpacity onPress={addTodo}>
        <View style={styles.iconContainer}>
          <Ionicons name="add" size={30} color='black' />
        </View>
      </TouchableOpacity>
    </View>
  </SafeAreaView>;
};

const styles = StyleSheet.create({
  actionIcon: {
    height: 25,
    width: 25,
    backgroundColor: 'green',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 5,
    borderRadius: 3,
  },
  listItem: {
    padding: 20,
    backgroundColor: COLORS.textbg,
    flexDirection: 'row',
    elevation: 12,
    borderRadius: 7,
    marginVertical: 10,
  },
  header: {
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  footer: {
    position: 'absolute',
    bottom: 0,
    backgroundColor: COLORS.textbg,
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 30,
  },
  inputContainer: {
    backgroundColor: COLORS.inputbox,
    elevation: 40,
    flex:  1,
    height: 100,
    marginVertical: 40,
    marginRight: 20,
    borderRadius: 30,
    paddingHorizontal: 20,
    paddingTop: 10,
  },
  iconContainer: {
    height: 50,
    width: 50,
    backgroundColor: COLORS.bg,
    borderRadius: 25,
    elevation: 60,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

const Stack = createNativeStackNavigator();

function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator 
      initialRouteName="Home"
      screenOptions={{
        headerStyle: {
          backgroundColor: COLORS.bg,
        },
        headerTintColor: COLORS.textbg,
        headerTitleStyle: {
          fontWeight: 'bold',
        },
      }}
      >
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Details" component={TodoDetails} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;