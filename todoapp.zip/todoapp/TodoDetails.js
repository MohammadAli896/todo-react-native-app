import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
const COLORS = {text: '#f8f7ff', textbg: "#003566", bg: "#FFC300", inputbox: '#e2eafc'};

const TodoDetails = ({ route }) => {
  const { todo } = route.params;

  return (
    <View style={styles.container}>
      <Text style={styles.todoName}>{todo.task}</Text>

      <View style={styles.summaryContainer}>
        <Text style={styles.summaryText}>{todo.summary}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: COLORS.bg,
  },
  todoName: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
    color: COLORS.textbg,
  },
  summaryContainer: {
    marginTop: 20,
    backgroundColor: COLORS.textbg,
    padding: 15,
    borderRadius: 10,
  },
  summaryText: {
    fontSize: 18,
    color: COLORS.text,
  },
});

export default TodoDetails;
